/**Class to demonstrate writing out a message
 * @author pwaite
 */
 public class FirstClassDemo {
     
     public static void main(String[] args) {
         System.out.println("Hello Class");
     }
 } 
 
