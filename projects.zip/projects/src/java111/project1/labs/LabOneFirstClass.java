/**
 * This is the first class in the first lab of the first semester of Java!
 * 
 * @author eknapp
 * 
 */
public class LabOneFirstClass {
 
    /**
     * This is the main method for this class
     * It will output a hello message
     * 
     * @param args
     */
    public static void main(String[] args) {
 
        System.out.println("Hi there!");
 
    }
 
}
